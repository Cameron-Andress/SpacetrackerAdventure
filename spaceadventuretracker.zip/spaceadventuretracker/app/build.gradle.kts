plugins {
    id("com.android.application") // Plugin for Android application
    kotlin("android") // Kotlin plugin for Android
    kotlin("plugin.compose") version "2.0.0" // Kotlin Compose plugin with version 2.0.0
}

android {
    namespace = "com.cameronandress.spaceadventuretracker"
    compileSdk = 35 // Set compile SDK to 35

    defaultConfig {
        applicationId = "com.cameronandress.spaceadventuretracker" // Application ID
        minSdk = 26 // Minimum SDK version
        targetSdk = 34 // Target SDK version
        versionCode = 1 // Version code
        versionName = "1.0" // Version name

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" // Test instrumentation runner
    }

    buildTypes {
        release {
            isMinifyEnabled = false // Disable minification in release build
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"), // Default ProGuard file
                "proguard-rules.pro" // Custom ProGuard rules file
            )
        }
    }

    buildFeatures {
        compose = true // Enable Jetpack Compose
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.3" // Specify the version of Compose compiler extension
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}" // Exclude certain resources from the package
        }
    }

    kotlinOptions {
        jvmTarget = "1.8" // Set JVM target to 1.8
    }
}

dependencies {
    implementation(libs.material.v1120) // Material Design library version 1.1.20
    implementation(libs.androidx.recyclerview) // RecyclerView library
    implementation(libs.androidx.appcompat.v170) // AppCompat library version 1.7.0
    implementation(libs.androidx.core.ktx) // AndroidX core KTX extensions
    implementation(libs.material3) // Material 3 library
    implementation(libs.ui) // UI library for Jetpack Compose
    implementation(libs.ui.tooling.preview) // Compose tooling preview
    implementation(libs.androidx.lifecycle.runtime.ktx) // Lifecycle runtime for Jetpack
    implementation(libs.androidx.activity.compose.v172) // Activity Compose library version 1.7.2
    implementation(libs.androidx.constraintlayout.compose) // ConstraintLayout for Compose
    implementation(libs.constraintlayout) // ConstraintLayout for Android views
    implementation(libs.filament.android) // Filament (3D rendering engine) for Android
    testImplementation(libs.junit) // JUnit testing library
    androidTestImplementation(libs.androidx.junit.v115) // AndroidX JUnit testing library version 1.1.5
    androidTestImplementation(libs.androidx.espresso.core.v351) // Espresso testing core library version 3.5.1
    androidTestImplementation(libs.ui.test.junit4) // UI testing with JUnit 4
    debugImplementation(libs.ui.tooling) // UI tooling library for debugging
    debugImplementation(libs.ui.test.manifest) // UI testing manifest for debugging
}
