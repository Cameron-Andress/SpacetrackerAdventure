package com.cameronandress.spaceadventuretracker.ui.theme

import android.content.Context
import com.cameronandress.spaceadventuretracker.R

object ThemeUtils {
    private const val PREF_NAME = "theme_preferences"
    private const val THEME_KEY = "current_theme"

    private fun applyTheme(context: Context) {
        val sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean(THEME_KEY, false)

        val theme = if (isDarkMode) R.style.Theme_SpaceAdventureTracker_Dark
        else R.style.Theme_SpaceAdventureTracker_Light

        context.setTheme(theme)
    }

    fun toggleTheme(context: Context) {
        val sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean(THEME_KEY, false)

        // Toggle the theme preference
        sharedPreferences.edit().putBoolean(THEME_KEY, !isDarkMode).apply()

        // Apply the theme immediately
        applyTheme(context)
    }
}
