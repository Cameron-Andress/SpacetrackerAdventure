package com.cameronandress.spaceadventuretracker.ui.theme

import androidx.compose.ui.graphics.Color

val Purple40 = Color(0xFF6200EE)
val PurpleGrey40 = Color(0xFF3700B3)
val Pink40 = Color(0xFF03DAC5)

val Purple80 = Color(0xFFBB86FC)
val PurpleGrey80 = Color(0xFF6200EA)
val Pink80 = Color(0xFF03DAC6)