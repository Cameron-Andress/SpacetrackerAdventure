package com.cameronandress.spaceadventuretracker

data class CelestialBody(
    val name: String,
    val distanceFromSun: String,
    val funFact: String,
    val imageResourceId: Int
)
