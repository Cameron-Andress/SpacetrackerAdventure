package com.cameronandress.spaceadventuretracker

import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import com.cameronandress.spaceadventuretracker.ui.theme.ThemeUtils

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Get references to views
        val themeSwitch = findViewById<Switch>(R.id.themeSwitch)
        val nasaButton = findViewById<Button>(R.id.nasaButton)

        // Initialize the switch based on current theme
        val sharedPreferences = getSharedPreferences("theme_preferences", MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("current_theme", false)
        themeSwitch.isChecked = isDarkMode

        // Set a listener to change the theme when the switch is toggled
        themeSwitch.setOnCheckedChangeListener { _, isChecked ->
            ThemeUtils.toggleTheme(this)
            // Save theme preference
            sharedPreferences.edit().putBoolean("current_theme", isChecked).apply()
        }

        // Handle button click to go to NASA website
        nasaButton.setOnClickListener {
            openNASA()
        }
    }

    // Function to open NASA website
    private fun openNASA() {
        val url = "https://www.nasa.gov"
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
        startActivity(intent)
    }
}
