package com.cameronandress.spaceadventuretracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CelestialAdapter(
    private val celestialBodies: List<CelestialBody>,
    private val onItemClicked: (CelestialBody) -> Unit
) : RecyclerView.Adapter<CelestialAdapter.CelestialViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CelestialViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_celestial_body, parent, false)
        return CelestialViewHolder(view)
    }

    override fun onBindViewHolder(holder: CelestialViewHolder, position: Int) {
        val celestialBody = celestialBodies[position]
        holder.bind(celestialBody, onItemClicked)
    }

    override fun getItemCount(): Int {
        return celestialBodies.size
    }

    class CelestialViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        private val imageView: ImageView = itemView.findViewById(R.id.imageView)
        private val distanceTextView: TextView = itemView.findViewById(R.id.distanceTextView)
        private val factTextView: TextView = itemView.findViewById(R.id.factTextView)

        fun bind(celestialBody: CelestialBody, onItemClicked: (CelestialBody) -> Unit) {
            nameTextView.text = celestialBody.name
            imageView.setImageResource(celestialBody.imageResourceId)
            distanceTextView.text = celestialBody.distanceFromSun
            factTextView.text = celestialBody.funFact

            itemView.setOnClickListener {
                onItemClicked(celestialBody)
            }
        }
    }
}
