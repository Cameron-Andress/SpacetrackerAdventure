package com.cameronandress.spaceadventuretracker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cameronandress.spaceadventuretracker.ui.theme.ThemeUtils

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var celestialAdapter: CelestialAdapter

    // Open NASA website
    fun openNASA() {
        val url = "https://www.nasa.gov"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(intent)
    }

    // Function to toggle between light and dark theme
    private fun changeTheme() {
        ThemeUtils.toggleTheme(this)
        // Show a message when the theme is changed
        Toast.makeText(this, "Theme Changed", Toast.LENGTH_SHORT).show()
        recreate() // Recreate the activity to apply the new theme
    }

    // Handle menu item clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_theme -> {
                changeTheme() // Call the changeTheme function when selected
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set up RecyclerView
        recyclerView = findViewById(R.id.recyclerView)

        val databaseHelper = DatabaseHelper(this)
        val celestialBodies = databaseHelper.getCelestialBodies()

        celestialAdapter = CelestialAdapter(celestialBodies) { selectedBody ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("name", selectedBody.name)
            intent.putExtra("distance", selectedBody.distanceFromSun)
            intent.putExtra("fact", selectedBody.funFact)
            intent.putExtra("image", selectedBody.imageResourceId)
            startActivity(intent)
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = celestialAdapter

        // Button to open NASA website
        val nasaButton = findViewById<Button>(R.id.nasaButton)
        nasaButton.setOnClickListener {
            openNASA() // Call openNASA when the button is clicked
        }
    }

    // Inflating the menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
}
