package com.cameronandress.spaceadventuretracker

import android.content.Context

class DatabaseHelper(private val context: Context) {
    fun getCelestialBodies(): List<CelestialBody> {
        return listOf(
            CelestialBody("Mercury", "57.91 million km from the Sun", "Smallest planet in the Solar System. It is only slightly larger than Earth' moon. Closest planet to the sun.", R.drawable.mercury),
            CelestialBody("Venus", "108.2 million km from the Sun", "Hottest planet due to thick atmosphere. Average temperature is 867 degrees Fahrenheit (464 degrees Celsius). ", R.drawable.venus),
            CelestialBody("Earth", "149.6 million km from the Sun", "Only planet known to support life. Nicknamed the Pale Blue Dot by Carl Sagan.", R.drawable.earth),
            CelestialBody("Mars", "227.9 million km from the Sun", "Has the largest mountain in the solar system, Olympus Mons.", R.drawable.mars),
            CelestialBody("Jupiter", "778.3 million km from the Sun", "Largest planet with the Great Red Spot. A storm that has been going on for the past 150 years according to NASA. One of the Galilean moons, Europa, has a chance ot have life under it's icy surface.", R.drawable.jupiter),
            CelestialBody("Saturn", "1.429 billion km from the Sun", "Famous for its ring system. It has strange hexagonal jet streams at the north pole.", R.drawable.saturn),
            CelestialBody("Uranus", "2.871 billion km from the Sun", "Has a unique sideways rotation. It gets its blue-green color from methane gas in the atmosphere. Sunlight passes through the atmosphere and is reflected back out by Uranus' cloud tops. Methane gas absorbs the red portion of the light, resulting in a blue-green color. ", R.drawable.uranus),
            CelestialBody("Neptune", "4.498 billion km from the Sun", "Coldest planet with supersonic winds reaching more than 1,200 miles per hour (2,000 kilometers per hour). Average temperature is -353 degrees Fahrenheit (-214 degrees Celsius).", R.drawable.neptune)
        )
    }
}
