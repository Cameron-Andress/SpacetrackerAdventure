package com.cameronandress.spaceadventuretracker

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Retrieve the data passed in the Intent
        val name = intent.getStringExtra("name") ?: "Unknown Name"
        val distance = intent.getStringExtra("distance") ?: "Unknown Distance"
        val fact = intent.getStringExtra("fact") ?: "No fact available"
        val image = intent.getIntExtra("image", R.drawable.default_image)

        // Find Views by ID
        val nameTextView = findViewById<TextView>(R.id.nameTextView)
        val distanceTextView = findViewById<TextView>(R.id.distanceTextView)
        val factTextView = findViewById<TextView>(R.id.factTextView)
        val imageView = findViewById<ImageView>(R.id.imageView)
        val nasaButton = findViewById<Button>(R.id.nasaButton)

        // Set data to views
        nameTextView.text = name
        distanceTextView.text = "Distance from Sun: $distance"
        factTextView.text = fact
        imageView.setImageResource(image)

        // Open NASA Website on Button Click
        nasaButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.nasa.gov"))
            startActivity(intent)
        }
    }
}
